/*
�m�W:�B���Q
�Ǹ�:d0542914
���g���:2017/12/03 
Dev-C++����:5.11
*/ 
#include<stdlib.h>
#include<stdio.h>
typedef struct listNode{//def struct of listNode 
	int data;
	listNode* link;
}listNode;
listNode *head = NULL;//public listNode pointer "head"
listNode* creatNode(){
	listNode *ptr = NULL;
	ptr = (listNode*)malloc(sizeof(listNode));//malloc listNode
	if (ptr != NULL)return ptr;else printf("create error!\n");//malloc error
}
int check(int number){//�ˬd�O�_�w�s�b�A�O�^��1�A�_�h0 
	listNode *ptr = head;
	while(ptr!=NULL){
		if(ptr->data == number)return 1;
		ptr = ptr->link;
	}
	return 0;
}
void add(int addNum){//�[�J�s�Ʀr 
	listNode *newptr = creatNode();
	newptr->data = addNum;newptr->link = NULL;
	if(head==NULL)head = newptr;
	else{
		if(!check(addNum)){//���ˬd���S������ 
			listNode *ptr = head;
			while(ptr->link!=NULL)ptr = ptr->link; //�U�@�� 
			ptr->link = newptr;//����̫�@�� 
		}else printf("error\n");
	}
}
void del(int delNum){//�R�� 
	if(check(delNum)){//���ˬd�n�R�����Ʀr�O�_�w�s�b 
		listNode* ptr = head;
		listNode* ptr2 = NULL;
		while(ptr!=NULL){
			if(ptr->data == delNum){
				if(ptr == head)head = head->link;//�R���Y�A���Y���U�@�� 
				else ptr2->link = ptr->link;
				free(ptr);
				return;
			}
			ptr2 = ptr;//�����n�R�����e�@��Node 
			ptr = ptr->link;//�U�@�� 
		}
	}else printf("not found\n");
}
void modify(int searchNum,int modifyNum){//�ק� 
	if(check(searchNum)){//���ˬd���ק蠟�Ʀr�O�_�s�b 
		add(modifyNum);//�����J 
		if(searchNum!=modifyNum)del(searchNum);//��R�� 
	}else printf("not found\n");
}
void link_sort(){//linked list select sort! 
	int temp;
	listNode *ptr = NULL,*ptr2 = NULL,*ptr3;
	for(ptr=head;ptr!=NULL;ptr=ptr->link){
		ptr3 = ptr;
		for(ptr2=ptr->link;ptr2!=NULL;ptr2=ptr2->link)
			if(ptr2->data < ptr3->data)ptr3 = ptr2;
		temp = ptr->data;ptr->data = ptr3->data;ptr3->data = temp;
	}
}
void print(){//list all Node
	listNode* ptr = head;
	while(ptr!=NULL){
		printf("%d ",ptr->data);
		ptr = ptr->link;
	}
	printf("\n");
}
int main(){
	int select,addNum,searchNum,modifyNum,delNum;
	while(1){
		printf("1.add 2.modify 3.delete 4.print 5.exit :");
		scanf("%d",&select);//select func
		fflush(stdin);
		if (select!=1&&select!=5){
			if (head==NULL){
				printf("empty\n");//linked list is empty.
				continue;
			}
		}
		switch(select){
			case 1:
				scanf("%d",&addNum);
				add(addNum);//add input=1,so it need scanf
				break;
			case 2:
				scanf("%d %d",&searchNum,&modifyNum);
				modify(searchNum,modifyNum);
				break;
			case 3:
				scanf("%d",&delNum);
				del(delNum);////deleteNode input=1,so it need scanf
				break;
			case 4:
				link_sort();
				print();
				break;
			case 5:
				return 0;
		}
	}
	return 0;
}

